# Pip Demo

[![PyPI - Version](https://img.shields.io/pypi/v/pip-demo.svg)](https://pypi.org/project/pip-demo)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pip-demo.svg)](https://pypi.org/project/pip-demo)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install pip-demo
```

## License

`pip-demo` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
