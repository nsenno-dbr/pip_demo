# SPDX-FileCopyrightText: 2024-present nsenno-dbr <nick.senno@databricks.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
